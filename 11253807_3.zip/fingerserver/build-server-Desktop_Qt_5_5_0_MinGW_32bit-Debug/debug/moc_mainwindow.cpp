/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../server/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[25];
    char stringdata0[636];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 14), // "connectSuccess"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 23), // "on_actionShow_triggered"
QT_MOC_LITERAL(4, 51, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(5, 75, 23), // "on_actionFind_triggered"
QT_MOC_LITERAL(6, 99, 24), // "on_actionClose_triggered"
QT_MOC_LITERAL(7, 124, 32), // "on_pushButtonSavefinger1_clicked"
QT_MOC_LITERAL(8, 157, 27), // "on_pushButtonConcel_clicked"
QT_MOC_LITERAL(9, 185, 25), // "on_pushButtonSure_clicked"
QT_MOC_LITERAL(10, 211, 24), // "on_pushButtonReg_clicked"
QT_MOC_LITERAL(11, 236, 26), // "on_pushButtonClose_clicked"
QT_MOC_LITERAL(12, 263, 32), // "on_pushButtonSavefinger2_clicked"
QT_MOC_LITERAL(13, 296, 32), // "on_pushButtoncheckfinger_clicked"
QT_MOC_LITERAL(14, 329, 28), // "on_pB_logoChangelink_clicked"
QT_MOC_LITERAL(15, 358, 29), // "on_pushButton_2_Start_clicked"
QT_MOC_LITERAL(16, 388, 27), // "on_pushButton_1_get_clicked"
QT_MOC_LITERAL(17, 416, 28), // "on_pushButton_1_show_clicked"
QT_MOC_LITERAL(18, 445, 28), // "on_pushButton_3_find_clicked"
QT_MOC_LITERAL(19, 474, 32), // "on_lineEdit_3_findId_textChanged"
QT_MOC_LITERAL(20, 507, 4), // "arg1"
QT_MOC_LITERAL(21, 512, 30), // "on_pushButton_3_delect_clicked"
QT_MOC_LITERAL(22, 543, 28), // "on_pushButton_3_back_clicked"
QT_MOC_LITERAL(23, 572, 32), // "on_pushButton_3_findName_clicked"
QT_MOC_LITERAL(24, 605, 30) // "on_pushButton_3_Updata_clicked"

    },
    "MainWindow\0connectSuccess\0\0"
    "on_actionShow_triggered\0on_actionSave_triggered\0"
    "on_actionFind_triggered\0"
    "on_actionClose_triggered\0"
    "on_pushButtonSavefinger1_clicked\0"
    "on_pushButtonConcel_clicked\0"
    "on_pushButtonSure_clicked\0"
    "on_pushButtonReg_clicked\0"
    "on_pushButtonClose_clicked\0"
    "on_pushButtonSavefinger2_clicked\0"
    "on_pushButtoncheckfinger_clicked\0"
    "on_pB_logoChangelink_clicked\0"
    "on_pushButton_2_Start_clicked\0"
    "on_pushButton_1_get_clicked\0"
    "on_pushButton_1_show_clicked\0"
    "on_pushButton_3_find_clicked\0"
    "on_lineEdit_3_findId_textChanged\0arg1\0"
    "on_pushButton_3_delect_clicked\0"
    "on_pushButton_3_back_clicked\0"
    "on_pushButton_3_findName_clicked\0"
    "on_pushButton_3_Updata_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    0,  135,    2, 0x08 /* Private */,
      14,    0,  136,    2, 0x08 /* Private */,
      15,    0,  137,    2, 0x08 /* Private */,
      16,    0,  138,    2, 0x08 /* Private */,
      17,    0,  139,    2, 0x08 /* Private */,
      18,    0,  140,    2, 0x08 /* Private */,
      19,    1,  141,    2, 0x08 /* Private */,
      21,    0,  144,    2, 0x08 /* Private */,
      22,    0,  145,    2, 0x08 /* Private */,
      23,    0,  146,    2, 0x08 /* Private */,
      24,    0,  147,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->connectSuccess(); break;
        case 1: _t->on_actionShow_triggered(); break;
        case 2: _t->on_actionSave_triggered(); break;
        case 3: _t->on_actionFind_triggered(); break;
        case 4: _t->on_actionClose_triggered(); break;
        case 5: _t->on_pushButtonSavefinger1_clicked(); break;
        case 6: _t->on_pushButtonConcel_clicked(); break;
        case 7: _t->on_pushButtonSure_clicked(); break;
        case 8: _t->on_pushButtonReg_clicked(); break;
        case 9: _t->on_pushButtonClose_clicked(); break;
        case 10: _t->on_pushButtonSavefinger2_clicked(); break;
        case 11: _t->on_pushButtoncheckfinger_clicked(); break;
        case 12: _t->on_pB_logoChangelink_clicked(); break;
        case 13: _t->on_pushButton_2_Start_clicked(); break;
        case 14: _t->on_pushButton_1_get_clicked(); break;
        case 15: _t->on_pushButton_1_show_clicked(); break;
        case 16: _t->on_pushButton_3_find_clicked(); break;
        case 17: _t->on_lineEdit_3_findId_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: _t->on_pushButton_3_delect_clicked(); break;
        case 19: _t->on_pushButton_3_back_clicked(); break;
        case 20: _t->on_pushButton_3_findName_clicked(); break;
        case 21: _t->on_pushButton_3_Updata_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::connectSuccess)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::connectSuccess()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
