/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionShow;
    QAction *actionSave;
    QAction *actionFind;
    QAction *actionClose;
    QWidget *centralWidget;
    QGridLayout *gridLayout_8;
    QStackedWidget *stackedWidget;
    QWidget *pageLog;
    QGridLayout *gridLayout_12;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_11;
    QLabel *label_logo_name;
    QLineEdit *lineEditUserName;
    QLabel *label_logo_passwd;
    QLineEdit *lineEditPassward;
    QHBoxLayout *horizontalLayout;
    QPushButton *pB_logoChangelink;
    QSpacerItem *horizontalSpacer_9;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButtonReg;
    QPushButton *pushButtonClose;
    QSpacerItem *horizontalSpacer_11;
    QSpacerItem *verticalSpacer_5;
    QWidget *pageShowInfo;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_1_show;
    QPushButton *pushButton_1_get;
    QTextEdit *textEdit_1_Show;
    QProgressBar *progressBar_1_get;
    QWidget *pageSave;
    QGridLayout *gridLayout_5;
    QGroupBox *groupBoxImage;
    QGridLayout *gridLayout_6;
    QWidget *widgetFinger;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *groupBoxInfo;
    QGridLayout *gridLayout_10;
    QGridLayout *gridLayout_4;
    QLabel *label_3;
    QLineEdit *lineEditname;
    QLabel *label_4;
    QLineEdit *lineEditID;
    QLabel *label_5;
    QLineEdit *lineEditdate;
    QGroupBox *groupBoxShow;
    QGridLayout *gridLayout_7;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_2_info;
    QSpacerItem *horizontalSpacer_5;
    QProgressBar *progressBar_2_fingerImage;
    QGroupBox *groupBoxDeal;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_2_Start;
    QPushButton *pushButtonSavefinger1;
    QPushButton *pushButtonSavefinger2;
    QPushButton *pushButtoncheckfinger;
    QPushButton *pushButtonSure;
    QPushButton *pushButtonConcel;
    QWidget *pageFind;
    QGridLayout *gridLayout_9;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *pushButton_3_findName;
    QLineEdit *lineEdit_3_findId;
    QPushButton *pushButton_3_find;
    QTextEdit *textEdit_3_show;
    QPushButton *pushButton_3_delect;
    QPushButton *pushButton_3_back;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *pushButton_3_Updata;
    QProgressBar *progressBar_3_show;
    QMenuBar *menuBar;
    QMenu *menuO;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(361, 563);
        actionShow = new QAction(MainWindow);
        actionShow->setObjectName(QStringLiteral("actionShow"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        actionFind = new QAction(MainWindow);
        actionFind->setObjectName(QStringLiteral("actionFind"));
        actionClose = new QAction(MainWindow);
        actionClose->setObjectName(QStringLiteral("actionClose"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_8 = new QGridLayout(centralWidget);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        pageLog = new QWidget();
        pageLog->setObjectName(QStringLiteral("pageLog"));
        gridLayout_12 = new QGridLayout(pageLog);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        verticalSpacer_3 = new QSpacerItem(20, 144, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_12->addItem(verticalSpacer_3, 0, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(43, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_3, 1, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        gridLayout_11 = new QGridLayout();
        gridLayout_11->setSpacing(6);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        label_logo_name = new QLabel(pageLog);
        label_logo_name->setObjectName(QStringLiteral("label_logo_name"));
        QFont font;
        font.setFamily(QStringLiteral("Arial"));
        font.setPointSize(12);
        label_logo_name->setFont(font);

        gridLayout_11->addWidget(label_logo_name, 0, 0, 1, 1);

        lineEditUserName = new QLineEdit(pageLog);
        lineEditUserName->setObjectName(QStringLiteral("lineEditUserName"));

        gridLayout_11->addWidget(lineEditUserName, 0, 1, 1, 1);

        label_logo_passwd = new QLabel(pageLog);
        label_logo_passwd->setObjectName(QStringLiteral("label_logo_passwd"));
        label_logo_passwd->setFont(font);

        gridLayout_11->addWidget(label_logo_passwd, 1, 0, 1, 1);

        lineEditPassward = new QLineEdit(pageLog);
        lineEditPassward->setObjectName(QStringLiteral("lineEditPassward"));

        gridLayout_11->addWidget(lineEditPassward, 1, 1, 1, 1);


        verticalLayout->addLayout(gridLayout_11);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pB_logoChangelink = new QPushButton(pageLog);
        pB_logoChangelink->setObjectName(QStringLiteral("pB_logoChangelink"));
        pB_logoChangelink->setStyleSheet(QStringLiteral("border: 0px;"));

        horizontalLayout->addWidget(pB_logoChangelink);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_9);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout_12->addLayout(verticalLayout, 1, 1, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(42, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_6, 1, 2, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 145, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_12->addItem(verticalSpacer_4, 2, 1, 1, 1);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_10);

        pushButtonReg = new QPushButton(pageLog);
        pushButtonReg->setObjectName(QStringLiteral("pushButtonReg"));

        horizontalLayout_8->addWidget(pushButtonReg);

        pushButtonClose = new QPushButton(pageLog);
        pushButtonClose->setObjectName(QStringLiteral("pushButtonClose"));

        horizontalLayout_8->addWidget(pushButtonClose);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_11);


        gridLayout_12->addLayout(horizontalLayout_8, 3, 0, 1, 3);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_12->addItem(verticalSpacer_5, 4, 1, 1, 1);

        stackedWidget->addWidget(pageLog);
        pageShowInfo = new QWidget();
        pageShowInfo->setObjectName(QStringLiteral("pageShowInfo"));
        gridLayout = new QGridLayout(pageShowInfo);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalSpacer = new QSpacerItem(228, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 1);

        label = new QLabel(pageShowInfo);
        label->setObjectName(QStringLiteral("label"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font1.setPointSize(26);
        label->setFont(font1);
        label->setTextFormat(Qt::RichText);
        label->setAlignment(Qt::AlignCenter);
        label->setMargin(0);

        gridLayout->addWidget(label, 0, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(227, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 2, 1, 1);

        pushButton_1_show = new QPushButton(pageShowInfo);
        pushButton_1_show->setObjectName(QStringLiteral("pushButton_1_show"));

        gridLayout->addWidget(pushButton_1_show, 1, 0, 1, 1);

        pushButton_1_get = new QPushButton(pageShowInfo);
        pushButton_1_get->setObjectName(QStringLiteral("pushButton_1_get"));

        gridLayout->addWidget(pushButton_1_get, 1, 2, 1, 1);

        textEdit_1_Show = new QTextEdit(pageShowInfo);
        textEdit_1_Show->setObjectName(QStringLiteral("textEdit_1_Show"));
        textEdit_1_Show->setStyleSheet(QStringLiteral("background : transparent;"));

        gridLayout->addWidget(textEdit_1_Show, 3, 0, 1, 3);

        progressBar_1_get = new QProgressBar(pageShowInfo);
        progressBar_1_get->setObjectName(QStringLiteral("progressBar_1_get"));
        progressBar_1_get->setValue(0);

        gridLayout->addWidget(progressBar_1_get, 2, 0, 1, 3);

        stackedWidget->addWidget(pageShowInfo);
        pageSave = new QWidget();
        pageSave->setObjectName(QStringLiteral("pageSave"));
        gridLayout_5 = new QGridLayout(pageSave);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        groupBoxImage = new QGroupBox(pageSave);
        groupBoxImage->setObjectName(QStringLiteral("groupBoxImage"));
        gridLayout_6 = new QGridLayout(groupBoxImage);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        gridLayout_6->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        widgetFinger = new QWidget(groupBoxImage);
        widgetFinger->setObjectName(QStringLiteral("widgetFinger"));
        gridLayout_3 = new QGridLayout(widgetFinger);
        gridLayout_3->setSpacing(7);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_7, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 90, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 0, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 89, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_2, 1, 1, 1, 1);


        gridLayout_6->addWidget(widgetFinger, 0, 0, 1, 1);


        gridLayout_5->addWidget(groupBoxImage, 0, 0, 1, 1);

        groupBoxInfo = new QGroupBox(pageSave);
        groupBoxInfo->setObjectName(QStringLiteral("groupBoxInfo"));
        gridLayout_10 = new QGridLayout(groupBoxInfo);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setSpacing(6);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        label_3 = new QLabel(groupBoxInfo);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(label_3, 0, 0, 1, 1);

        lineEditname = new QLineEdit(groupBoxInfo);
        lineEditname->setObjectName(QStringLiteral("lineEditname"));

        gridLayout_4->addWidget(lineEditname, 0, 1, 1, 1);

        label_4 = new QLabel(groupBoxInfo);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(label_4, 1, 0, 1, 1);

        lineEditID = new QLineEdit(groupBoxInfo);
        lineEditID->setObjectName(QStringLiteral("lineEditID"));

        gridLayout_4->addWidget(lineEditID, 1, 1, 1, 1);

        label_5 = new QLabel(groupBoxInfo);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_4->addWidget(label_5, 2, 0, 1, 1);

        lineEditdate = new QLineEdit(groupBoxInfo);
        lineEditdate->setObjectName(QStringLiteral("lineEditdate"));

        gridLayout_4->addWidget(lineEditdate, 2, 1, 1, 1);


        gridLayout_10->addLayout(gridLayout_4, 0, 0, 1, 1);


        gridLayout_5->addWidget(groupBoxInfo, 1, 0, 1, 1);

        groupBoxShow = new QGroupBox(pageSave);
        groupBoxShow->setObjectName(QStringLiteral("groupBoxShow"));
        gridLayout_7 = new QGridLayout(groupBoxShow);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_4);

        label_2_info = new QLabel(groupBoxShow);
        label_2_info->setObjectName(QStringLiteral("label_2_info"));
        QFont font2;
        font2.setFamily(QStringLiteral("Arial"));
        font2.setPointSize(20);
        label_2_info->setFont(font2);
        label_2_info->setTextFormat(Qt::PlainText);
        label_2_info->setAlignment(Qt::AlignCenter);

        horizontalLayout_6->addWidget(label_2_info);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_5);


        gridLayout_7->addLayout(horizontalLayout_6, 0, 0, 1, 1);


        gridLayout_5->addWidget(groupBoxShow, 2, 0, 1, 1);

        progressBar_2_fingerImage = new QProgressBar(pageSave);
        progressBar_2_fingerImage->setObjectName(QStringLiteral("progressBar_2_fingerImage"));
        progressBar_2_fingerImage->setValue(0);

        gridLayout_5->addWidget(progressBar_2_fingerImage, 3, 0, 1, 1);

        groupBoxDeal = new QGroupBox(pageSave);
        groupBoxDeal->setObjectName(QStringLiteral("groupBoxDeal"));
        gridLayout_2 = new QGridLayout(groupBoxDeal);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        pushButton_2_Start = new QPushButton(groupBoxDeal);
        pushButton_2_Start->setObjectName(QStringLiteral("pushButton_2_Start"));

        gridLayout_2->addWidget(pushButton_2_Start, 0, 0, 1, 1);

        pushButtonSavefinger1 = new QPushButton(groupBoxDeal);
        pushButtonSavefinger1->setObjectName(QStringLiteral("pushButtonSavefinger1"));

        gridLayout_2->addWidget(pushButtonSavefinger1, 0, 1, 1, 1);

        pushButtonSavefinger2 = new QPushButton(groupBoxDeal);
        pushButtonSavefinger2->setObjectName(QStringLiteral("pushButtonSavefinger2"));

        gridLayout_2->addWidget(pushButtonSavefinger2, 0, 2, 1, 1);

        pushButtoncheckfinger = new QPushButton(groupBoxDeal);
        pushButtoncheckfinger->setObjectName(QStringLiteral("pushButtoncheckfinger"));

        gridLayout_2->addWidget(pushButtoncheckfinger, 1, 0, 1, 1);

        pushButtonSure = new QPushButton(groupBoxDeal);
        pushButtonSure->setObjectName(QStringLiteral("pushButtonSure"));

        gridLayout_2->addWidget(pushButtonSure, 1, 1, 1, 1);

        pushButtonConcel = new QPushButton(groupBoxDeal);
        pushButtonConcel->setObjectName(QStringLiteral("pushButtonConcel"));

        gridLayout_2->addWidget(pushButtonConcel, 1, 2, 1, 1);


        gridLayout_5->addWidget(groupBoxDeal, 4, 0, 1, 1);

        stackedWidget->addWidget(pageSave);
        pageFind = new QWidget();
        pageFind->setObjectName(QStringLiteral("pageFind"));
        gridLayout_9 = new QGridLayout(pageFind);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        pushButton_3_findName = new QPushButton(pageFind);
        pushButton_3_findName->setObjectName(QStringLiteral("pushButton_3_findName"));
        pushButton_3_findName->setStyleSheet(QStringLiteral("border: 0px;"));

        horizontalLayout_9->addWidget(pushButton_3_findName);

        lineEdit_3_findId = new QLineEdit(pageFind);
        lineEdit_3_findId->setObjectName(QStringLiteral("lineEdit_3_findId"));

        horizontalLayout_9->addWidget(lineEdit_3_findId);

        pushButton_3_find = new QPushButton(pageFind);
        pushButton_3_find->setObjectName(QStringLiteral("pushButton_3_find"));

        horizontalLayout_9->addWidget(pushButton_3_find);


        gridLayout_9->addLayout(horizontalLayout_9, 0, 0, 1, 3);

        textEdit_3_show = new QTextEdit(pageFind);
        textEdit_3_show->setObjectName(QStringLiteral("textEdit_3_show"));

        gridLayout_9->addWidget(textEdit_3_show, 2, 0, 1, 3);

        pushButton_3_delect = new QPushButton(pageFind);
        pushButton_3_delect->setObjectName(QStringLiteral("pushButton_3_delect"));

        gridLayout_9->addWidget(pushButton_3_delect, 3, 0, 1, 3);

        pushButton_3_back = new QPushButton(pageFind);
        pushButton_3_back->setObjectName(QStringLiteral("pushButton_3_back"));

        gridLayout_9->addWidget(pushButton_3_back, 4, 0, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(114, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_9->addItem(horizontalSpacer_8, 4, 1, 1, 1);

        pushButton_3_Updata = new QPushButton(pageFind);
        pushButton_3_Updata->setObjectName(QStringLiteral("pushButton_3_Updata"));

        gridLayout_9->addWidget(pushButton_3_Updata, 4, 2, 1, 1);

        progressBar_3_show = new QProgressBar(pageFind);
        progressBar_3_show->setObjectName(QStringLiteral("progressBar_3_show"));
        progressBar_3_show->setValue(0);

        gridLayout_9->addWidget(progressBar_3_show, 1, 0, 1, 3);

        stackedWidget->addWidget(pageFind);

        gridLayout_8->addWidget(stackedWidget, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 361, 23));
        menuO = new QMenu(menuBar);
        menuO->setObjectName(QStringLiteral("menuO"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuO->menuAction());
        menuO->addAction(actionShow);
        menuO->addAction(actionSave);
        menuO->addAction(actionFind);
        menuO->addAction(actionClose);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionShow->setText(QApplication::translate("MainWindow", "\346\230\276\347\244\272", 0));
        actionSave->setText(QApplication::translate("MainWindow", "\345\275\225\346\214\207\347\272\271", 0));
        actionFind->setText(QApplication::translate("MainWindow", "\346\237\245\346\211\276", 0));
        actionClose->setText(QApplication::translate("MainWindow", "\351\200\200\345\207\272", 0));
        label_logo_name->setText(QApplication::translate("MainWindow", "\347\224\250\346\210\267\345\220\215\357\274\232", 0));
        label_logo_passwd->setText(QApplication::translate("MainWindow", "\345\257\206  \347\240\201\357\274\232", 0));
        pB_logoChangelink->setText(QApplication::translate("MainWindow", "\346\233\264\346\224\271\350\277\236\346\216\245\350\267\257\345\276\204\357\274\237", 0));
        pushButtonReg->setText(QApplication::translate("MainWindow", "\347\231\273\351\231\206", 0));
        pushButtonClose->setText(QApplication::translate("MainWindow", "\351\200\200\345\207\272", 0));
        label->setText(QApplication::translate("MainWindow", "\346\227\245\345\277\227", 0));
        pushButton_1_show->setText(QApplication::translate("MainWindow", "\350\216\267\345\217\226\344\277\241\346\201\257", 0));
        pushButton_1_get->setText(QApplication::translate("MainWindow", "\344\270\213\350\275\275\346\233\264\346\226\260", 0));
        groupBoxImage->setTitle(QApplication::translate("MainWindow", "\346\214\207\347\272\271\345\233\276\345\203\217", 0));
        groupBoxInfo->setTitle(QApplication::translate("MainWindow", "\346\214\207\347\272\271\344\277\241\346\201\257", 0));
        label_3->setText(QApplication::translate("MainWindow", "\345\275\225\345\210\266\344\272\272\345\247\223\345\220\215\357\274\232", 0));
        label_4->setText(QApplication::translate("MainWindow", "\345\275\225\345\210\266\344\272\272\347\232\204ID\357\274\232", 0));
        label_5->setText(QApplication::translate("MainWindow", "\345\275\225\345\210\266\347\232\204\346\227\266\351\227\264\357\274\232", 0));
        groupBoxShow->setTitle(QApplication::translate("MainWindow", "\344\277\241\346\201\257\346\230\276\347\244\272", 0));
        label_2_info->setText(QApplication::translate("MainWindow", "\347\255\211\345\276\205......", 0));
        groupBoxDeal->setTitle(QApplication::translate("MainWindow", "\346\214\207\347\272\271\345\244\204\347\220\206", 0));
        pushButton_2_Start->setText(QApplication::translate("MainWindow", "\345\274\200\345\220\257", 0));
        pushButtonSavefinger1->setText(QApplication::translate("MainWindow", "\345\275\225\346\214\207\347\272\271", 0));
        pushButtonSavefinger2->setText(QApplication::translate("MainWindow", "\345\275\225\346\214\207\347\272\271", 0));
        pushButtoncheckfinger->setText(QApplication::translate("MainWindow", "\346\243\200\351\252\214\345\207\206\347\241\256\345\272\246", 0));
        pushButtonSure->setText(QApplication::translate("MainWindow", "\347\241\256\345\256\232", 0));
        pushButtonConcel->setText(QApplication::translate("MainWindow", "\350\277\224\345\233\236", 0));
        pushButton_3_findName->setText(QApplication::translate("MainWindow", "\346\237\245\346\211\276id\357\274\232", 0));
        pushButton_3_find->setText(QApplication::translate("MainWindow", "\346\237\245\346\211\276", 0));
        pushButton_3_delect->setText(QApplication::translate("MainWindow", "\345\210\240\351\231\244", 0));
        pushButton_3_back->setText(QApplication::translate("MainWindow", "\345\244\207\344\273\275\346\225\260\346\215\256\345\272\223", 0));
        pushButton_3_Updata->setText(QApplication::translate("MainWindow", "\344\270\212\344\274\240\346\225\260\346\215\256\345\272\223", 0));
        menuO->setTitle(QApplication::translate("MainWindow", "\350\217\234\345\215\225", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
