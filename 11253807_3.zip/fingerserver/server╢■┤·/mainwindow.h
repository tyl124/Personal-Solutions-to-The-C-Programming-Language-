#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QTcpServer"
#include "QTcpSocket"
#include "QPaintEvent"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    //初始化数据
    void initData();
    //初始化tcp
    void initTcp();
    //设置tcp连接
    bool tcpLink(int mode = 0);

    //发送数据给服务器
    void sendDataToServe();
    //处理接收的数据
    void dealReceiveData();
    //接收文件
    void recData();
    //处理接收的返回值检测
    void recCheck(QString check);
    //画图事件
    void paintEvent(QPaintEvent *);
    //显示文本
    QString showFile(QString fileName);

signals:
    void connectSuccess();

private slots:
    //菜单显示事件
    void on_actionShow_triggered();

    void on_actionSave_triggered();

    void on_actionFind_triggered();

    void on_actionClose_triggered();  // 菜单退出

    //button事件
    void on_pushButtonSavefinger1_clicked(); //录指纹1

    void on_pushButtonConcel_clicked(); //取消录指纹

    void on_pushButtonSure_clicked(); //确定录取

    void on_pushButtonReg_clicked(); //登陆服务器

    void on_pushButtonClose_clicked(); //关闭窗口

    void on_pushButtonSavefinger2_clicked(); //录制指纹 2

    void on_pushButtoncheckfinger_clicked(); //检验两次录取准确度

    void on_pB_logoChangelink_clicked();  // 登陆界面改变link

    void on_pushButton_2_Start_clicked();  //申请资源

    void on_pushButton_1_get_clicked();   //获取日志

    void on_pushButton_1_show_clicked();  //显示日志

    void on_pushButton_3_find_clicked();  //查找人

    void on_lineEdit_3_findId_textChanged(const QString &arg1);

    void on_pushButton_3_delect_clicked(); //删除信息

    void on_pushButton_3_back_clicked(); //备份数据库

    void on_pushButton_3_findName_clicked();

private:
    Ui::MainWindow *ui;

    //tcp套接字指针
    QTcpSocket *tcpSocket;
    QString ip;
    quint16 port;

    int showImage; //显示哪个界面
    bool isLoad; //是否登陆
    bool isChangeLink;
    int recWhat; //接收的什么数据
    bool isOccupy; //是否占用指纹资源
    /* *
     * 哪个函数发送的tcp请求
     * 1,登陆
     * */
    int callFunc;

    QString filePath; //文件路径
    QFile fileTransport;//文件对象
    QString fileName;//文件名字
    qint64 fileSize;//文件大小
    qint64 recvSize;//已经发送的文件的大小
    bool isStart;  //接收头文件
    bool showInfo; //接收完成后

    QString findWhat; //按什么查找数据库
};

#endif // MAINWINDOW_H
