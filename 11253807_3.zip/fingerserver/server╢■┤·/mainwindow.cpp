#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"
#include "QPainter"
#include "QBrush"
#include "QPaintDevice"
#include "QMessageBox"
#include "QSqlDatabase"
#include "QSqlError"
#include "QString"
#include "QFileDialog"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initData();//初始化数据函数
    initTcp();
}

MainWindow::~MainWindow()
{
    delete ui;
}


//初始化数据函数
void MainWindow::initData()
{
    /* ================== 初始化登陆 ==================*/
    showImage = 3;
    //设置当前显示页面
    ui->stackedWidget->setCurrentWidget(ui->pageLog);
    //没登陆不使能菜单,设置密码不可见
    ui->menuO->setEnabled(false);
    //设置编辑框模式
    ui->lineEditUserName->setEnabled(true);
    ui->lineEditPassward->setEnabled(true);
    ui->lineEditPassward->setEchoMode(QLineEdit::Password);
    ui->pB_logoChangelink->setStyleSheet("#pB_logoChangelink{border: 0px;}"
                                         "#pB_logoChangelink:hover{color:rgb(0, 170, 255)};");
    isChangeLink=false;
    /* ================== 初始化界面1 ==================*/
    //显示文本框
    ui->textEdit_1_Show->setEnabled(true);
    ui->pushButton_1_get->setEnabled(true);
    ui->pushButton_1_show->setEnabled(true);
    ui->progressBar_1_get->setValue(0);
    ui->progressBar_1_get->hide();
    /* ================== 初始化界面2 ==================*/
    //button
    isOccupy = false;
    ui->pushButton_2_Start->setText("开启");
    ui->pushButton_2_Start->setEnabled(true);
    ui->pushButtonConcel->setEnabled(false);
    ui->pushButtonSure->setEnabled(false);
    ui->pushButtoncheckfinger->setEnabled(false);
    ui->pushButtonSavefinger1->setEnabled(false);
    ui->pushButtonSavefinger2->setEnabled(false);
    //label
    ui->label_2_info->setText("请放入手指！");
    ui->label_2_info->hide();
    //progressBar
    ui->progressBar_2_fingerImage->hide();

    /* ================ 初始化界面3 ====================== */
    findWhat = "id";
    ui->pushButton_3_findName->setText("查找id：");
    ui->pushButton_3_find->setEnabled(true);
    ui->lineEdit_3_findId->setEnabled(true);
    ui->pushButton_3_delect->setEnabled(false);
    ui->pushButton_3_back->setEnabled(true);  // 备份
    ui->progressBar_3_show->setValue(0);
    ui->progressBar_3_show->hide();
    ui->pushButton_3_findName->setStyleSheet("#pushButton_3_findName{border: 0px;}"
                                         "#pushButton_3_findName:hover{color:rgb(0, 170, 255)};");


    /*===================== tcp数据 ======================*/
    //文件接收
    isStart = true;
    //初始化tcp登陆
    isLoad = false;
    callFunc = 0;
    recWhat = 0;
    showInfo = false; 
}

//初始化有关tcp connect
void MainWindow::initTcp()
{
    //ip和端口
//    ip = "127.0.0.1";
//    port = 8080;

    ip = "192.168.137.249";
    port = 9090;
    //套接字
    tcpSocket = new QTcpSocket(this);
    //接收到服务器后发数据
    connect(tcpSocket, &QTcpSocket::connected, this, &MainWindow::sendDataToServe);
    //收信号
    connect(tcpSocket, &QTcpSocket::readyRead, this, &MainWindow::dealReceiveData);
    //对话框 × 掉
//    connect(this, &MainWindow::destroyed, this, &MainWindow::on_actionClose_triggered);
     connect(this, &MainWindow::destroyed, this,
             [=]()
             {
                 qDebug() << "distory";
             }
     );
}

//设置tcp连接
bool MainWindow::tcpLink(int mode)
{
    //tcp连接等待超时
    tcpSocket->disconnectFromHost();
    tcpSocket->close();
    tcpSocket->connectToHost(QHostAddress(ip), port);

    if(!tcpSocket->waitForConnected(100))  //等待5s
    {
        if(0 == mode)
        {
            recCheck("link_error");
        }
        return false;
    }
    return true;
}

//成功连接服务器后的响应
void MainWindow::sendDataToServe()
{
    switch (callFunc) {
    case 1: {//登陆请求
        //给对方发送数据,使用套接字是tcpSocket;  QString->QByteArray->char*
        QString userName = ui->lineEditUserName->text();
        QString passWord = ui->lineEditPassward->text();
        QString sendData = QString("{'userName':'%1', 'passWord':'%2'}")
                .arg(userName).arg(passWord);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 2: {//发送录制指纹1
        QString cmd = "finger";
        QString data = "1";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 3: {//发送录制指纹2
        QString cmd = "finger";
        QString data = "2";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 4: {//发送校验信息
        QString cmd = "check";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 5: {//存储有效指纹数据
        QString cmd = "save";
        QString name = ui->lineEditname->text();
        QString id = ui->lineEditID->text();
        QString date = ui->lineEditdate->text();
        QString data = QString("%1##%2##%3").arg(id).arg(name).arg(date);
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 6:{ // 发送占用指纹资源
        QString cmd = "occupy";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 7:{ // 发送释放指纹资源
        QString cmd = "release";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 8:{ // 界面1获取log
        QString cmd = "getLog";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 9:{ // 查找人
        QString cmd = "findPeople";
        QString data = QString("%1:%2").arg(findWhat).arg(ui->lineEdit_3_findId->text());
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 10:{ // 删除信息
        QString cmd = "delectPeople";
        QString data = QString("%1:%2").arg(findWhat).arg(ui->lineEdit_3_findId->text());
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 11:{ // 备份数据库
        QString cmd = "databaseBack";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
    }
        break;
    case 20: {//发送退出程序信号
        QString cmd = "close";
        QString data = "None";
        QString sendData = QString("{'cmd':'%1', 'value':'%2'}").arg(cmd).arg(data);
        tcpSocket->write(sendData.toUtf8().data());
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();
        QMainWindow::close();
    }
        break;
    default:
        break;
    }
}

//接收事件槽函数
void MainWindow::dealReceiveData()
{
    //接收的数据
    switch (callFunc) {
    case 1: {// 登陆获取信息
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();
        if(check != "True")  // 登陆失败或连接错误
        {
            recCheck(check);
            return ;
        }
        //登陆成功
        showImage = 1;
        isLoad = true;
        ui->menuO->setEnabled(true);
        ui->stackedWidget->setCurrentWidget(ui->pageShowInfo);

    } break;

    case 2:{ //接收录制指纹1
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if(check != "True")
        {
            recCheck(check);
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            break ;
        }
        ui->label_2_info->setText("请等待---");
        ui->label_2_info->show();
        ui->progressBar_2_fingerImage->show();
        callFunc = 20;
    } break;

    case 3:{ //接收录制指纹2
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if(check != "True")
        {
            recCheck(check);
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            break ;
        }
        ui->label_2_info->setText("请等待---");
        ui->label_2_info->show();
        ui->progressBar_2_fingerImage->show();
        callFunc = 20;
    } break;

    case 4:{  //两次指纹对比度
        QByteArray buf = tcpSocket->readAll();
        QString str = QString(buf);
        //解析返回值
        QString check = QString(str).section("##", 0, 0);
        QString score = QString(str).section("##", 1, 1);
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();

        if("True" != check)
            return recCheck(check);
        //检验合格
        QMessageBox::information(this, "检验", QString("检验合格，分数：%1").arg(score));
        ui->pushButtonSure->setEnabled(true);
    } break;

    case 5:{  //存储
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();

        if("True" != check)
            return recCheck(check);
        QMessageBox::information(this, "save", QString("储存成功！"));

        on_pushButtonConcel_clicked();

    } break;

    case 6:{  // 接收占用指纹资源是否成功
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();

        if("True" != check)
            return recCheck(check);
        //开启后使能和显示提示
        ui->label_2_info->show();
        ui->label_2_info->setText("开启成功");
        ui->pushButtonSavefinger1->setEnabled(true);
        ui->pushButton_2_Start->setText("关闭");
    } break;

    case 7:{  // 接收释放指纹资源是否成功
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        tcpSocket->disconnectFromHost(); //关闭tcp
        tcpSocket->close();

        if("True" != check)
            return recCheck(check);
        QMessageBox::information(this, "release", QString("关闭成功！"));
        //关闭后隐藏和禁止button
        ui->label_2_info->hide();
        ui->progressBar_2_fingerImage->hide();
        ui->pushButton_2_Start->setText("开启");

    } break;

    case 8:{  // 获取接收log
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if("True" != check){
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            return recCheck(check);
        }
        callFunc = 20;

    } break;

    case 9:{ // 查找人
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if("True" != check){
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            return recCheck(check);
        }
        callFunc = 20;
    } break;

    case 10:{ // 删除人
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if("True" != check){
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            return recCheck(check);
        }
        QMessageBox::information(this, "删除", QString("删除成功！"));
    } break;

    case 11:{ // 备份数据库
        QByteArray buf = tcpSocket->readAll();
        QString check = QString(buf);
        if("True" != check){
            tcpSocket->disconnectFromHost(); //关闭tcp
            tcpSocket->close();
            return recCheck(check);
        }
        callFunc = 20;
    } break;

    case 20:{
        recData();
        //显示进度条
        switch (recWhat){
        case 1:{
            ui->progressBar_1_get->setValue((100 * recvSize) / fileSize);
        } break;
        case 2:{
            ui->progressBar_2_fingerImage->setValue((100 * recvSize) / fileSize);
        } break;
        case 3:{
            ui->progressBar_2_fingerImage->setValue((100 * recvSize) / fileSize);
        } break;
        case 4:{
        } break;
        case 5:{
            ui->progressBar_3_show->setValue((100 * recvSize) / fileSize);
        } break;
        default: break;
        }
        //传输完成后
        if(showInfo == true)
        {
            showInfo = false;
            callFunc = 0;
            QMessageBox::information(this, "完成", "接收完成");
            switch (recWhat) {
            case 1:{
                recWhat = 0;
                ui->pushButton_1_get->setEnabled(true);
                ui->progressBar_1_get->hide();
            } break;
            case 2:{
                ui->pushButtonSavefinger2->setEnabled(true);
                showImage = 2;
                update();
                recWhat = 0;
            } break;
            case 3:{
                ui->pushButtoncheckfinger->setEnabled(true);
                showImage = 2;
                update();
                recWhat = 0;
            } break;
            case 4:{
                ui->textEdit_3_show->clear();
                QString str = showFile("find.txt");
                ui->textEdit_3_show->append(str);
                ui->pushButton_3_find->setEnabled(true);
                ui->lineEdit_3_findId->setEnabled(true);
                ui->pushButton_3_delect->setEnabled(true);
                recWhat = 0;
            } break;
            case 5:{
                ui->pushButton_3_back->setEnabled(true);
                ui->progressBar_3_show->hide();
                recWhat = 0;
            } break;
            default: break;
            }
        }
    } break;
    default: break;
    }

}

//获取文件
void MainWindow::recData()
{
    QByteArray buf = tcpSocket->readAll();
    QString check = QString(buf);

    if(true == isStart)
    {
        qDebug() << buf;
        isStart = false;
        //解析传回的头文件
        fileName = QString(buf).section("##", 0, 0);
        fileSize = QString(buf).section("##", 1, 1).toInt();
        recvSize = 0;  //初始化接收数据大小

        qDebug() << fileName << fileSize;
        if (0 == fileSize){  // 文件大小为0
            tcpSocket->disconnectFromHost();
            tcpSocket->close();
            return recCheck("fileError");
        }

        fileTransport.setFileName(fileName);

        bool isOk = fileTransport.open(QIODevice::WriteOnly);
        if(false == isOk)
        {
            qDebug() << "WriteOnly error 40";
        }
        tcpSocket->write(QString("True").toUtf8().data());


    }
    else
    {
        qint64 len = fileTransport.write(buf);
        recvSize += len;
        if(recvSize == fileSize)  //判断是否传输完成
        {
            fileTransport.close();
            tcpSocket->disconnectFromHost();
            tcpSocket->close();
            //准备新的传输
            isStart = true;
            showInfo = true;
        }
    }
}


//接收的信号做检测
void MainWindow::recCheck(QString check)
{
    qDebug() << check;
    if ("error" == check){// 连接失败或者是登陆失败
        if(false == isLoad)
            QMessageBox::warning(this, "连接信息", "用户名或者密码错误!");
        else
            QMessageBox::warning(this, "连接信息", "连接断开，重新登陆!");
        initData();
    }
    else if("102" == check){// 没有检测到手指
        ui->label_2_info->setText("请放入手指！");
        ui->label_2_info->show();
        switch (callFunc) {
        case 2:{
            ui->pushButtonSavefinger1->setEnabled(true);
        } break;
        case 3:{
            ui->pushButtonSavefinger2->setEnabled(true);
        }break;
        default: break;
        }
    }
    else if ("302" == check) { // 校验失败
        QMessageBox::warning(this, "校验信息", "两次指纹不匹配!");
        this->on_pushButtonConcel_clicked();
    }
    else if("link_error" == check) // 找不到服务器
    {
        QMessageBox::about(this, "连接信息", "连接失败......");
        initData();
    }
    else if("occupyError" == check) //抢占失败
    {
        QMessageBox::about(this, "占用信息", "设备正忙......");
        isOccupy = false;
    }
    else if("getLogError" == check)
    {
        QMessageBox::about(this, "获取日志", "失败！");
        ui->progressBar_1_get->hide();
        ui->pushButton_1_get->setEnabled(true);
    }
    else if("findError" == check)
    {
        QMessageBox::about(this, "查找", "失败！没这个人");
        ui->pushButton_3_find->setEnabled(true);
        ui->lineEdit_3_findId->setEnabled(true);
        ui->textEdit_3_show->clear();
    }
    else if("delectError" == check)
    {
        QMessageBox::about(this, "删除", "删除失败！");
    }
    else if("outPutError" == check)
    {
        QMessageBox::about(this, "导出数据库", "导出失败！");
        ui->pushButton_3_back->setEnabled(true);
    }
    else if("fileError" == check)
    {
        QMessageBox::about(this, "文件错误", "文件错误！");
    }
    else
    {
        QMessageBox::about(this, "错误错误", "错误错误");
    }
}

//绘图事件
void MainWindow::paintEvent(QPaintEvent *)
{

    QPainter p;
    //QPaintDevice pD;
    p.begin(this);//指定当前出窗口为绘图设备

    /* *
     * showImage
     * 1,显示页面颜色绘图
     * 2,指纹页面绘图
     * 3,查询页面绘图
     * */
    switch (showImage) {
    case 1:      
//        ui->pageShowInfo->setStyleSheet("#pageShowInfo{"
//                                       "border-image:url(:/image/image/car.jpg);"
//                                       "}"
//                                       );
//        break;

    case 2:{
        QString str = QString("QWidget{"
                      "border-image:url(finger.bmp);"
                      "}");
        ui->widgetFinger->setStyleSheet(str);
    }
        break;

    case 3:

        break;

    default:
        break;
    }

    p.end();
}

//显示文本
QString MainWindow::showFile(QString fileName)
{
    QFile file(fileName);
    ui->textEdit_1_Show->clear();
    bool isOk = file.open(QIODevice::ReadOnly);
    if(false == isOk)
    {
        qDebug() << "WriteOnly error 40";
    }
    QByteArray buff = file.readAll();
    QString str = QString(buff);
    return str;
}
/***================= 菜单函数 ===================***/
//显示界面
void MainWindow::on_actionShow_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->pageShowInfo);
    showImage = 1;
    update();

}

//录指纹界面
void MainWindow::on_actionSave_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->pageSave);
    showImage = 2;
    update();
}

//查找界面
void MainWindow::on_actionFind_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->pageFind);
    showImage = 3;
    update();
}

//菜单栏退出
void MainWindow::on_actionClose_triggered()
{
    /***********连接服务器发送数据***********/
    callFunc = 20;
    bool check = tcpLink(1);    //不要默认模式 0
    if(false == check)
    {
        MainWindow::close();
    }
}

/*** ===================界面登陆的函数========================== ***/
//登陆函数
void MainWindow::on_pushButtonReg_clicked()
{
    //禁止输入
    ui->lineEditUserName->setEnabled(false);
    ui->lineEditPassward->setEnabled(false);

    tcpSocket->disconnectFromHost();
    tcpSocket->close();
    //连接服务器
    callFunc = 1;
    tcpLink();  //默认模式 0

}


//退出函数
void MainWindow::on_pushButtonClose_clicked()
{
    QMainWindow::close();
}

//改变连接端口
void MainWindow::on_pB_logoChangelink_clicked()
{
    if(false == isChangeLink)
    {
        isChangeLink = true;
        ui->pB_logoChangelink->setText("返回？");
        //清楚编辑行文本
        ui->lineEditUserName->clear();
        ui->lineEditPassward->clear();
        //设置端口和ip
        ui->label_logo_name->setText("ip :");
        ui->label_logo_passwd->setText("port :");
        ui->lineEditPassward->setEchoMode(QLineEdit::Normal);  //设置正常显示
        //隐藏登陆
        ui->pushButtonReg->hide();

        qDebug() << ip << port;
    }
    else
    {
        isChangeLink = false;
        ui->pB_logoChangelink->setText("更改登陆连接？");
        //设置端口和ip
        ip = ui->lineEditUserName->text();
        port = ui->lineEditPassward->text().toInt();
        //清楚编辑行文本
        ui->lineEditUserName->clear();
        ui->lineEditPassward->clear();
        //设置为登陆模式
        ui->label_logo_name->setText("用户名：");
        ui->label_logo_passwd->setText("密 码：");
        ui->lineEditPassward->setEchoMode(QLineEdit::Password);
        //显示登陆
        ui->pushButtonReg->show();

        qDebug() << ip << port;
    }
}
/*** ===================界面1的函数========================== */
//在窗口显示信息
void MainWindow::on_pushButton_1_show_clicked()
{
    QString str = showFile("log.txt");
    ui->textEdit_1_Show->append(str);
}
//下载更新log
void MainWindow::on_pushButton_1_get_clicked()
{
    ui->pushButton_1_get->setEnabled(false);
    //显示进度条
    ui->progressBar_1_get->setValue(0);
    ui->progressBar_1_get->show();
    /***********连接服务器发送数据***********/
    recWhat = 1;
    callFunc = 8;
    tcpLink();  //默认模式 0
}
/*** ===================界面2的函数========================== */
//开启录制，占用资源
void MainWindow::on_pushButton_2_Start_clicked()
{
    if(false == isOccupy)  //开启占用
    {
        isOccupy = true;
        /***********连接服务器发送数据***********/
        callFunc = 6;
        //tcp连接
        tcpLink();
    }
    else  // 释放
    {
        isOccupy = false;
        //禁止button
        ui->pushButtonSavefinger1->setEnabled(false);
        ui->pushButtonConcel->setEnabled(false);
        ui->pushButtonSavefinger2->setEnabled(false);
        ui->pushButtonSure->setEnabled(false);
        ui->pushButtoncheckfinger->setEnabled(false);
        //隐藏进度条
        ui->progressBar_2_fingerImage->setValue(0);
        ui->progressBar_2_fingerImage->hide();
        /***********连接服务器发送数据***********/
        callFunc = 7;
        //tcp连接
        tcpLink();
    }
}

//录制指纹 1 Button
void MainWindow::on_pushButtonSavefinger1_clicked()
{
    //使能返回button和禁止录制button
    ui->pushButtonSavefinger1->setEnabled(false);
    ui->pushButtonConcel->setEnabled(true);
    //禁止输入
    ui->lineEditname->setEnabled(false);
    ui->lineEditID->setEnabled(false);
    ui->lineEditdate->setEnabled(false);
    //隐藏进度条
    ui->progressBar_2_fingerImage->setValue(0);
    ui->progressBar_2_fingerImage->hide();
    /***********连接服务器发送数据***********/
    callFunc = 2;
    recWhat = 2;
    tcpLink();  //默认模式 0

}

//录制指纹 2 Button
void MainWindow::on_pushButtonSavefinger2_clicked()
{
    //禁止button
    ui->pushButtonSavefinger2->setEnabled(false);
    //隐藏进度条
    ui->progressBar_2_fingerImage->setValue(0);
    ui->progressBar_2_fingerImage->hide();
    /***********连接服务器发送数据***********/
    callFunc = 3;
    recWhat = 3;
    tcpLink();  //默认模式 0


}

//检验两次录取准确度
void MainWindow::on_pushButtoncheckfinger_clicked()
{
    ui->pushButtoncheckfinger->setEnabled(false);
    /***********连接服务器发送数据***********/
    callFunc = 4;    
    tcpLink();  //默认模式 0
}


//取消录取操作
void MainWindow::on_pushButtonConcel_clicked()
{
    //开启输入
    ui->lineEditname->setEnabled(true);
    ui->lineEditID->setEnabled(true);
    ui->lineEditdate->setEnabled(true);
    //button功能转换
    ui->pushButtonSavefinger1->setEnabled(true);
    ui->pushButtonConcel->setEnabled(false);
    ui->pushButtonSavefinger2->setEnabled(false);
    ui->pushButtonSure->setEnabled(false);
    //隐藏显示信息
    ui->label_2_info->hide();
    ui->progressBar_2_fingerImage->hide();
    //关闭连接主机
    tcpSocket->disconnectFromHost();
    tcpSocket->close();
    //关闭文件
    fileTransport.close();
    isStart = true;
    showInfo = false;
}

//更新数据库
void MainWindow::on_pushButtonSure_clicked()
{
    ui->pushButtonSure->setEnabled(false);
    //弹出对话框提醒用户是否更新
    QString str = "是否跟新到数据库";
    int isOk = QMessageBox::information(this, "issave", str, QMessageBox::Ok, QMessageBox::Cancel);

    if (QMessageBox::Cancel == isOk)
    {
        on_pushButtonConcel_clicked();
        return;
    }

//    /*================== 数据库的操作 ==============*/
//    //添加MySql数据库
//    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
//    //连接数据库
//    db.setHostName("127.0.0.1"); //数据库服务器IP
//    db.setUserName("root"); //数据库用户名
//    db.setPassword("123456"); //密码
//    db.setDatabaseName("myinfo"); //使用哪个数据库

//    //打开数据库
//    if(false == db.open()) //数据库打开失败
//    {
//        QMessageBox::warning(this, "错误", db.lastError().text());
//        return;

//    }

//    db.close();
    callFunc = 5;
    tcpLink();  //默认模式 0

}

/*** ===================界面3的函数========================== */
//查找人
void MainWindow::on_pushButton_3_find_clicked()
{
    ui->pushButton_3_find->setEnabled(false);
    ui->lineEdit_3_findId->setEnabled(false);
    /***********连接服务器发送数据***********/
    callFunc = 9;
    recWhat = 4;
    tcpLink();  //默认模式 0
}

//删除信息
void MainWindow::on_pushButton_3_delect_clicked()
{
    ui->pushButton_3_delect->setEnabled(false);
    /***********连接服务器发送数据***********/
    callFunc = 10;
    tcpLink();  //默认模式 0
}
//输入框变化
void MainWindow::on_lineEdit_3_findId_textChanged(const QString &arg1)
{
    ui->pushButton_3_delect->setEnabled(false);
}

//备份数据库
void MainWindow::on_pushButton_3_back_clicked()
{
    ui->pushButton_3_back->setEnabled(false);
    ui->progressBar_3_show->setValue(0);
    ui->progressBar_3_show->show();
    /***********连接服务器发送数据***********/
    callFunc = 11;
    recWhat = 5;
    tcpLink();  //默认模式 0

}
//按查找的名字
void MainWindow::on_pushButton_3_findName_clicked()
{
    QString txt = ui->pushButton_3_findName->text();
    if("查找id：" == txt)
    {
        ui->pushButton_3_findName->setText("查找name：");
        findWhat = "name";
    }
    else if("查找name：" == txt)
    {
        ui->pushButton_3_findName->setText("查找date：");
        findWhat = "time";
    }
    else if("查找date：" == txt)
    {
        ui->pushButton_3_findName->setText("查找id：");
        findWhat = "id";
    }
}
